import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';
import './CreatePool.css';

import deployedFactory from '../../../hardhat/saveDeployArtifacts/factory.json';

const UNISWAP_V3_FACTORY_ADDRESS = deployedFactory.address;

const UNISWAP_V3_FACTORY_ABI = [
  'function createPool(address tokenA, address tokenB, uint24 fee) external returns (address pool)',
  'function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool)',
  'event PoolCreated(address indexed token0, address indexed token1, uint24 indexed fee, int24 tickSpacing, address pool)',
];

import { useWallet } from '@hooks/useWallet';

const CreatePool = ({ onCreate = () => {} }) => {
const { isConnected, getSigner, connect } = useWallet(); 


if (import.meta.env.DEV) {
  console.log('Signer:', getSigner);
  console.log('isConnected:', isConnected);
}


  const [tokenAAddress, setTokenAAddress] = useState('');
  const [tokenAAmount, setTokenAAmount] = useState('');
  const [tokenBAddress, setTokenBAddress] = useState('');
  const [tokenBAmount, setTokenBAmount] = useState('');
  const [feeTier, setFeeTier] = useState('0.3'); // Maps to 500 (0.05%), 3000 (0.3%), 10000 (1%)
  const [existingPools, setExistingPools] = useState([]);
  const [resultMessage, setResultMessage] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Validate Ethereum address format
  const isValidAddress = (address) => /^0x[a-fA-F0-9]{40}$/.test(address);

  // Convert fee tier percentage to Uniswap V3 fee (in basis points)
  const feeTierToUint24 = (tier) => {
    switch (tier) {
      case '0.05': return 500;
      case '0.3': return 3000;
      case '1': return 10000;
      default: return 3000;
    }
  };

  // Load existing pools from localStorage
  useEffect(() => {
    const pools = JSON.parse(localStorage.getItem('pools') || '[]');
    setExistingPools(pools);
  }, []);

  // Handle pool creation
const handleSubmit = async (e) => {
  e.preventDefault();
  setIsLoading(true);

  const signer = await getSigner();
  if (!signer) {
    setError('No signer found. Please reconnect your wallet.');
    setIsLoading(false);
    return;
  }

  // Input validation
  if (!isValidAddress(tokenAAddress) || !isValidAddress(tokenBAddress)) {
    setError('Invalid token address format.');
    setIsLoading(false);
    return;
  }
  if (tokenAAddress.toLowerCase() === tokenBAddress.toLowerCase()) {
    setError('Token A and Token B addresses must be different.');
    setIsLoading(false);
    return;
  }
  if (parseFloat(tokenAAmount) <= 0 || parseFloat(tokenBAmount) <= 0) {
    setError('Amounts must be positive numbers.');
    setIsLoading(false);
    return;
  }

  try {
    const factoryContract = new ethers.Contract(
      UNISWAP_V3_FACTORY_ADDRESS,
      UNISWAP_V3_FACTORY_ABI,
      signer
    );

    const [token0, token1] = tokenAAddress.toLowerCase() < tokenBAddress.toLowerCase()
      ? [tokenAAddress, tokenBAddress]
      : [tokenBAddress, tokenAAddress];

    const fee = feeTierToUint24(feeTier);
    const existingPool = await factoryContract.getPool(token0, token1, fee);

    if (existingPool !== ethers.constants.AddressZero) {
      setError('Pool already exists. Use Add Liquidity instead.');
      setIsLoading(false);
      return;
    }

    const tx = await factoryContract.createPool(token0, token1, fee, { gasLimit: 5_000_000 });
    const receipt = await tx.wait();

    const poolAddress = receipt.events.find(e => e.event === 'PoolCreated')?.args?.pool;
    if (!poolAddress) throw new Error('Pool address not found in tx receipt.');

    const newPool = {
      tokenAAddress,
      tokenAAmount,
      tokenBAddress,
      tokenBAmount,
      feeTier,
      poolAddress,
      createdAt: new Date().toISOString(),
    };
// Reset form
    onCreate(newPool);
    const updatedPools = [...existingPools, newPool];
    localStorage.setItem('pools', JSON.stringify(updatedPools));
    setExistingPools(updatedPools);
    setTokenAAddress('');
    setTokenAAmount('');
    setTokenBAddress('');
    setTokenBAmount('');
    setFeeTier('0.3');
    setResultMessage(`✅ Pool created at ${poolAddress}!`);
  } catch (err) {
    setError('Failed to create pool: ' + (err.reason || err.message));
  } finally {
    setIsLoading(false);
  }
};


  return (
    <div className="create-pool">
      <h2>Create New Pool</h2>
      <p>Create a new trading pair between two tokens with a selected fee tier.</p>
      
      <form onSubmit={handleSubmit} aria-labelledby="create-pool-form">
        <div className="input-group">
          <label htmlFor="tokenAAddress">Token A Address</label>
          <input
            id="tokenAAddress"
            type="text"
            value={tokenAAddress}
            onChange={(e) => setTokenAAddress(e.target.value)}
            placeholder="0x..."
            required
            aria-required="true"
            disabled={!isConnected}
          />
        </div>
        <div className="input-group">
          <label htmlFor="tokenAAmount">Token A Amount</label>
          <input
            id="tokenAAmount"
            type="number"
            step="0.0001"
            min="0"
            value={tokenAAmount}
            onChange={(e) => setTokenAAmount(e.target.value)}
            required
            aria-required="true"
            disabled={!isConnected}
          />
        </div>
        <div className="input-group">
          <label htmlFor="tokenBAddress">Token B Address</label>
          <input
            id="tokenBAddress"
            type="text"
            value={tokenBAddress}
            onChange={(e) => setTokenBAddress(e.target.value)}
            placeholder="0x..."
            required
            aria-required="true"
            disabled={!isConnected}
          />
        </div>
        <div className="input-group">
          <label htmlFor="tokenBAmount">Token B Amount</label>
          <input
            id="tokenBAmount"
            type="number"
            step="0.0001"
            min="0"
            value={tokenBAmount}
            onChange={(e) => setTokenBAmount(e.target.value)}
            required
            aria-required="true"
            disabled={!isConnected}
          />
        </div>
        <div className="input-group">
          <label htmlFor="feeTier">Fee Tier</label>
          <select
            id="feeTier"
            value={feeTier}
            onChange={(e) => setFeeTier(e.target.value)}
            required
            aria-required="true"
            disabled={!isConnected}
          >
            <option value="0.05">0.05% (Low Volatility)</option>
            <option value="0.3">0.3% (Medium Volatility)</option>
            <option value="1">1% (High Volatility)</option>
          </select>
        </div>
        <button
          type="submit"
          disabled={!isConnected || !tokenAAddress || !tokenBAddress || !tokenAAmount || !tokenBAmount || isLoading}
        >
          {isLoading ? 'Creating Pool...' : 'Create Pool'}
        </button>
      </form>
      {error && <p className="error-message">{error}</p>}
      {resultMessage && <p className="result-message">{resultMessage}</p>}
    </div>
  );
};

export default CreatePool;