// deploy/deployAll.js
const hre = require("hardhat");
const ethers = hre.ethers;
const fs = require("fs");
const path = require("path");

// 1) Import your deploy scripts:
const deployLibraries = require("./deployLibraries");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying from account:", deployer.address);

  // 2) Log deployer balance
  const balance = await ethers.provider.getBalance(deployer.address);
  console.log("Deployer balance:", ethers.formatEther(balance), "ETH\n");

  // 3) Deploy libraries (TickMath, SqrtPriceMath)
  console.log("🔧 Deploying: Libraries");
  const libraries = await deployLibraries();
  console.log("");

  // 4) Deploy WETH9
  console.log("🔧 Deploying: WETH9");
  const WETH9 = await ethers.getContractFactory("WETH9");
  const weth = await WETH9.deploy();
  await weth.waitForDeployment();
  const wethAddress = await weth.getAddress();
  console.log("WETH9 deployed to:", wethAddress, "\n");

  // 5) Deploy UniswapV3Factory
  console.log("🔧 Deploying: UniswapV3Factory");
  const Factory = await ethers.getContractFactory("UniswapV3Factory");
  const factory = await Factory.deploy();
  await factory.waitForDeployment();
  const factoryAddress = await factory.getAddress();
  console.log("Factory deployed to:", factoryAddress, "\n");

  // 6) Deploy PoolDeployer
  console.log("🔧 Deploying: UniswapV3PoolDeployer");
  const PoolDeployer = await ethers.getContractFactory("UniswapV3PoolDeployer");
  const poolDeployer = await PoolDeployer.deploy();
  await poolDeployer.waitForDeployment();
  const poolDeployerAddress = await poolDeployer.getAddress();
  console.log("PoolDeployer deployed to:", poolDeployerAddress, "\n");

  // 7) Deploy UniswapV3Pool with linked libraries
  console.log("🔧 Deploying: UniswapV3Pool with libraries");
  const PoolFactory = await ethers.getContractFactory("UniswapV3Pool", {
    libraries: {
      TickMath: libraries.TickMath,
      SqrtPriceMath: libraries.SqrtPriceMath,
      Tick: libraries.Tick,
      FullMath: libraries.FullMath,
      SwapMath: libraries.SwapMath,
      Position: libraries.Position,
      Oracle: libraries.Oracle,
    },
  });
  const pool = await PoolFactory.deploy();
  await pool.waitForDeployment();
  const poolAddress = await pool.getAddress();
  console.log("UniswapV3Pool deployed to:", poolAddress, "\n");

  //ChainId
  console.log("🔧 Deploying: ChainId");
  const ChainId = await ethers.getContractFactory("ChainId");
  const chainId = await ChainId.deploy();
  await chainId.waitForDeployment();
  const chainIdAddress = await chainId.getAddress();
  console.log("ChainId deployed to:", chainIdAddress, "\n");


  // 8) Deploy NonfungibleTokenPositionDescriptor
  console.log("🔧 Deploying: NonfungibleTokenPositionDescriptor");
  const Descriptor = await ethers.getContractFactory("NonfungibleTokenPositionDescriptor");
  const descriptor = await Descriptor.deploy(wethAddress);
  await descriptor.waitForDeployment();
  const descriptorAddress = await descriptor.getAddress();
  console.log("Descriptor deployed to:", descriptorAddress, "\n");

  // 9) Deploy NonfungiblePositionManager
  console.log("🔧 Deploying: NonfungiblePositionManager");
  const Manager = await ethers.getContractFactory("NonfungiblePositionManager");
  const manager = await Manager.deploy(factoryAddress, wethAddress, descriptorAddress);
  await manager.waitForDeployment();
  const managerAddress = await manager.getAddress();
  console.log("Manager deployed to:", managerAddress, "\n");

  // 10) Deploy SwapRouter
  console.log("🔧 Deploying: SwapRouter");
  const Router = await ethers.getContractFactory("SwapRouter");
  const router = await Router.deploy(factoryAddress, wethAddress);
  await router.waitForDeployment();
  const routerAddress = await router.getAddress();
  console.log("Router deployed to:", routerAddress, "\n");

  // 11) Save all deployed addresses
  const deployments = {
    Libraries: libraries,
    WETH9: wethAddress,
    Factory: factoryAddress,
    PoolDeployer: poolDeployerAddress,
    UniswapV3Pool: poolAddress,
    NonfungibleTokenPositionDescriptor: descriptorAddress,
    NonfungiblePositionManager: managerAddress,
    SwapRouter: routerAddress,
  };
  const outPath = path.join(__dirname, "artifacts", "deployments.json");
  fs.writeFileSync(outPath, JSON.stringify(deployments, null, 2));
  console.log("✅ All contracts deployed. Addresses saved to deploy/artifacts/deployments.json");
}

main().catch((err) => {
  console.error("❌ Deployment failed:", err);
  process.exitCode = 1;
});
