import React, { useState, useEffect } from 'react';
import PoolCard from './PoolCard';
import CreatePool from './CreatePool';
import './Pools.css';
import { useNavigate } from 'react-router-dom';

const Pools = () => {
  const [activeView, setActiveView] = useState('view');
  const [pools, setPools] = useState([]);
  const navigate = useNavigate();
  
  useEffect(() => {
    const fetchedPools = [
      {
        id: 1,
        tokenAAddress: '0xTokenA',
        tokenAAmount: 100,
        tokenBAddress: '0xTokenB',
        tokenBAmount: 200,
      },
    ];
    setPools(fetchedPools);
  }, []);

  const addPool = (newPool) => {
    setPools((prevPools) => [...prevPools, { id: prevPools.length + 1, ...newPool }]);
  };

  const handleViewPool = (pool) => {
    alert(`Viewing pool: ${pool.tokenAAddress} - ${pool.tokenBAddress}`);
  };

  return (
    <div className="liquidity-container">
      <div className="view-toggle">
        <button className={activeView === 'view' ? 'active' : ''} onClick={() => setActiveView('view')}>
          View Pools
        </button>
        <button onClick={() => navigate('/add-liquidity')}>
          Add Liquidity
        </button>
      </div>

      {activeView === 'view' && (
        <div className="pool-view">
          <h2>Liquidity Pools</h2>
          <div className="pools-grid">
            {pools.length ? (
              pools.map((pool) => (
                <PoolCard key={pool.id} pool={pool} onView={handleViewPool} />
              ))
            ) : (
              <p>No pools available.</p>
            )}
          </div>
        </div>
      )}

      {activeView === 'add' && <CreatePool onCreate={addPool} />}
    </div>
  );
};

export default Pools;
