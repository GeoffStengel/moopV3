// deploy/deployLibraries.js
const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");
const hre = require("hardhat"); // For hre.network.name

async function main() {
  console.log("🌐 Starting library deployment script...");
  console.log("📍 Network:", hre.network.name);

  // Get deployer
  const [deployer] = await ethers.getSigners();
  console.log("👤 Deployer address:", deployer.address);
  const balance = await ethers.provider.getBalance(deployer.address);
  const formatEther = ethers.utils?.formatEther || ethers.formatEther;
  console.log("💰 Deployer balance:", formatEther(balance), "ETH");
  
  const libraries = {};

  // Deploy TickMath
  console.log("📚 Deploying TickMath...");
  const TickMathFactory = await ethers.getContractFactory("contracts/uniswap/libraries/TickMath.sol:TickMath");
  const tickMath = await TickMathFactory.deploy({ gasLimit: 3000000 });
  await tickMath.waitForDeployment();
  const tickMathAddress = await tickMath.getAddress();
  console.log("🎉 TickMath deployed to:", tickMathAddress);
  libraries.TickMath = tickMathAddress;

  // Deploy SqrtPriceMath
  console.log("📚 Deploying SqrtPriceMath...");
  const SqrtPriceMathFactory = await ethers.getContractFactory("contracts/uniswap/libraries/SqrtPriceMath.sol:SqrtPriceMath");
  const sqrtPriceMath = await SqrtPriceMathFactory.deploy({ gasLimit: 3000000 });
  await sqrtPriceMath.waitForDeployment();
  const sqrtPriceMathAddress = await sqrtPriceMath.getAddress();
  console.log("🎉 SqrtPriceMath deployed to:", sqrtPriceMathAddress);
  libraries.SqrtPriceMath = sqrtPriceMathAddress;

  // Deploy FullMath
  console.log("📚 Deploying FullMath...");
  const FullMathFactory = await ethers.getContractFactory("contracts/uniswap/libraries/FullMath.sol:FullMath");
  const fullMath = await FullMathFactory.deploy({ gasLimit: 3000000 });
  await fullMath.waitForDeployment();
  const fullMathAddress = await fullMath.getAddress();
  console.log("🎉 FullMath deployed to:", fullMathAddress);
  libraries.FullMath = fullMathAddress;

  // Deploy SwapMath
  console.log("📚 Deploying SwapMath...");
  const SwapMathFactory = await ethers.getContractFactory("contracts/uniswap/libraries/SwapMath.sol:SwapMath");
  const swapMath = await SwapMathFactory.deploy({ gasLimit: 3000000 });
  await swapMath.waitForDeployment();
  const swapMathAddress = await swapMath.getAddress();
  console.log("🎉 SwapMath deployed to:", swapMathAddress);
  libraries.SwapMath = swapMathAddress;

  // Deploy Tick
  console.log("📚 Deploying Tick...");
  const TickFactory = await ethers.getContractFactory("contracts/uniswap/libraries/Tick.sol:Tick");
  const tick = await TickFactory.deploy({ gasLimit: 3000000 });
  await tick.waitForDeployment();
  const tickAddress = await tick.getAddress();
  console.log("🎉 Tick deployed to:", tickAddress);
  libraries.Tick = tickAddress;

  // Deploy Position
  console.log("📚 Deploying Position...");
  const PositionFactory = await ethers.getContractFactory("contracts/uniswap/libraries/Position.sol:Position");
  const position = await PositionFactory.deploy({ gasLimit: 3000000 });
  await position.waitForDeployment();
  const positionAddress = await position.getAddress();
  console.log("🎉 Position deployed to:", positionAddress);
  libraries.Position = positionAddress;

  // Deploy Oracle
  console.log("📚 Deploying Oracle...");
  const OracleFactory = await ethers.getContractFactory("contracts/uniswap/libraries/Oracle.sol:Oracle");
  const oracle = await OracleFactory.deploy({ gasLimit: 3000000 });
  await oracle.waitForDeployment();
  const oracleAddress = await oracle.getAddress();
  console.log("🎉 Oracle deployed to:", oracleAddress);
  libraries.Oracle = oracleAddress;

  // Save to JSON
  const artifactDir = path.resolve(__dirname, "../saveDeployArtifacts");
  const librariesPath = path.join(artifactDir, "libraries.json");
  console.log("💾 Saving library addresses to:", librariesPath);

  if (!fs.existsSync(artifactDir)) {
    fs.mkdirSync(artifactDir, { recursive: true });
    console.log("📂 Created directory:", artifactDir);
  }

  console.log("📋 Directory contents before writing:", fs.readdirSync(artifactDir));
  fs.writeFileSync(librariesPath, JSON.stringify(libraries, null, 2));
  console.log("✅ Library addresses saved");
  console.log("📋 Directory contents after writing:", fs.readdirSync(artifactDir));

  return libraries;
}

main()
  .then(() => {
    console.log("🎉 Library deployment completed successfully");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Deployment failed:", err.message);
    process.exit(1);
  });