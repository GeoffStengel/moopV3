// deploy/SwapRouter.js
const fs = require("fs");
const path = require("path");
const { ethers } = require("hardhat");
const hre = require("hardhat"); // For hre.network.name and hre.run
const { getLinkedFactory } = require("./utils/linkLibraries");

async function main() {
  console.log("🛠️ Starting SwapRouter deployment script...");
  console.log("🌐 Deploying to network:", hre.network.name);

  // Get deployer
  const [deployer] = await ethers.getSigners();
  console.log("👤 Deploying SwapRouter with account:", deployer.address);
  const balance = await ethers.provider.getBalance(deployer.address);
  const formatEther = ethers.utils?.formatEther || ethers.formatEther; // Keeps compatibility
  console.log("💰 Deployer balance:", formatEther(balance), "ETH");


  // Check for required artifacts
  const artifactDir = path.resolve(__dirname, "../saveDeployArtifacts");
  const factoryPath = path.join(artifactDir, "factory.json");
  const wethPath = path.join(artifactDir, "weth9.json");
  const librariesPath = path.join(artifactDir, "libraries.json");

  console.log("🔍 Checking for required artifacts...");
  if (!fs.existsSync(factoryPath) || !fs.existsSync(wethPath)) {
    throw new Error("🚨 Required artifacts (factory.json or weth9.json) not found in saveDeployArtifacts");
  }
  if (!fs.existsSync(librariesPath)) {
    throw new Error("🚨 libraries.json not found. Deploy libraries first.");
  }

  const { factoryAddress } = JSON.parse(fs.readFileSync(factoryPath));
  const { wethAddress } = JSON.parse(fs.readFileSync(wethPath));
  const libraries = JSON.parse(fs.readFileSync(librariesPath));
  console.log("🏭 Factory address:", factoryAddress);
  console.log("💸 WETH9 address:", wethAddress);
  console.log("📚 Libraries:", Object.keys(libraries));

  if ((await ethers.provider.getCode(factoryAddress)) === "0x") {
    throw new Error("🚫 Invalid factory address: no code deployed");
  }
  if ((await ethers.provider.getCode(wethAddress)) === "0x") {
    throw new Error("🚫 Invalid WETH9 address: no code deployed");
  }

  console.log("📚 Loading SwapRouter contract factory...");
  const SwapRouterFactory = await ethers.getContractFactory(
  "contracts/uniswap/SwapRouter.sol:SwapRouter"
);
  console.log("🚀 Deploying SwapRouter...");
  const routerInstance = await SwapRouterFactory.deploy(factoryAddress, wethAddress, { gasLimit: 6000000 });
  await routerInstance.waitForDeployment();

  const address = await routerInstance.getAddress();
  console.log("🎉 SwapRouter deployed to:", address);

  const artifactPath = path.join(artifactDir, "swapRouter.json");
  console.log("📋 Directory contents before writing:", fs.readdirSync(artifactDir));
  fs.writeFileSync(artifactPath, JSON.stringify({ address }, null, 2));
  console.log("💾 SwapRouter address saved to:", artifactPath);
  console.log("📋 Directory contents after writing:", fs.readdirSync(artifactDir));

  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    console.log("🔎 Verifying SwapRouter on Etherscan...");
    try {
      await hre.run("verify:verify", {
        address,
        constructorArguments: [factoryAddress, wethAddress],
      });
      console.log("✅ SwapRouter verified on Etherscan");
    } catch (err) {
      console.error("❌ Etherscan verification failed:", err.message);
    }
  }
}

main()
  .then(() => {
    console.log("🎉 SwapRouter deployment completed successfully");
    process.exit(0);
  })
  .catch((err) => {
    console.error("❌ Deployment failed:", err.message);
    process.exit(1);
  });