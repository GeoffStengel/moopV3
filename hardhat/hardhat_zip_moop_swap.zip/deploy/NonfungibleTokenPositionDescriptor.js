const { ethers } = require("hardhat");
const fs = require("fs");
const { getLinkedFactory } = require("./utils/linkLibraries");

module.exports = async () => {
  const [deployer] = await ethers.getSigners();
  const hre = require("hardhat");
  console.log("Deploying to network:", hre.network.name);
  console.log("Deploying NonfungiblePositionDescriptor with account:", deployer.address);
  console.log("Deployer balance:", ethers.utils.formatEther(await deployer.getBalance()), "ETH");

  // Check for required artifact
  if (!fs.existsSync("artifacts/weth9.json")) {
    throw new Error("Required artifact (weth9.json) not found");
  }
  const { wethAddress } = JSON.parse(fs.readFileSync("artifacts/weth9.json"));

  const DescriptorFactory = await getLinkedFactory(
    "contracts/uniswap/NonfungiblePositionDescriptor.sol:NonfungiblePositionDescriptor"
  );
  const descriptorInstance = await DescriptorFactory.deploy(wethAddress);
  await descriptorInstance.waitForDeployment();

  const address = await descriptorInstance.getAddress();
  console.log("NonfungiblePositionDescriptor deployed to:", address);

  fs.writeFileSync(
    "artifacts/positionDescriptor.json",
    JSON.stringify({ descriptorAddress: address }, null, 2)
  );

  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    try {
      console.log("Verifying NonfungiblePositionDescriptor on Etherscan...");
      await hre.run("verify:verify", { address, constructorArguments: [wethAddress] });
    } catch (err) {
      console.error("Etherscan verification failed:", err.message);
    }
  }
};