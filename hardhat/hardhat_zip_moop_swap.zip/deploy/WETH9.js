// deploy/WETH9.js
const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  console.log("Starting WETH9 deployment script...");

  // Verify Hardhat environment
  const hre = require("hardhat");
  console.log("Hardhat network:", hre.network.name);
  if (hre.network.name !== "localhost" && hre.network.name !== "hardhat") {
    console.log("WARNING: Not running on localhost or hardhat network");
  }

  // Get deployer
  let deployer;
  try {
    [deployer] = await ethers.getSigners();
    console.log("Deployer address:", deployer.address);
    const balance = await ethers.provider.getBalance(deployer.address);
    console.log("Deployer balance:", ethers.formatEther(balance), "ETH");
    if (balance < ethers.parseEther("0.1")) {
      throw new Error("Insufficient deployer balance (< 0.1 ETH)");
    }
  } catch (err) {
    throw new Error(`Failed to get deployer: ${err.message}`);
  }

  // Verify contract compilation
  console.log("Attempting to load WETH9 contract...");
  let WETH9Factory;
  try {
    WETH9Factory = await ethers.getContractFactory("WETH9");
    console.log("WETH9 contract factory loaded successfully");
  } catch (err) {
    throw new Error(`Failed to load WETH9 contract: ${err.message}. Check if contracts/WETH9.sol exists and is compiled.`);
  }

  // Deploy WETH9
  console.log("Deploying WETH9...");
  let weth9;
  try {
    weth9 = await WETH9Factory.deploy({ gasLimit: 5000000 });
    await weth9.waitForDeployment();
    const wethAddress = await weth9.getAddress();
    console.log("WETH9 deployed to:", wethAddress);
  } catch (err) {
    throw new Error(`WETH9 deployment failed: ${err.message}`);
  }

  // Save address to artifacts
  try {
    const artifactDir = path.resolve(__dirname, "../saveDeployArtifacts");
    const artifactPath = path.join(artifactDir, "weth9.json");
    console.log("Attempting to save artifact to:", artifactPath);

    // Ensure artifacts directory exists
    if (!fs.existsSync(artifactDir)) {
      fs.mkdirSync(artifactDir, { recursive: true });
      console.log("Created artifacts directory:", artifactDir);
    }

    // List directory before writing
    console.log("Directory contents before writing:", fs.readdirSync(artifactDir));

    // Write artifact
    fs.writeFileSync(artifactPath, JSON.stringify({ wethAddress: await weth9.getAddress() }, null, 2));
    console.log("WETH9 address saved to:", artifactPath);

    // Verify file exists
    if (fs.existsSync(artifactPath)) {
      console.log("Verified: weth9.json exists");
    } else {
      throw new Error("Failed to verify weth9.json existence");
    }

    // List directory after writing
    console.log("Directory contents after writing:", fs.readdirSync(artifactDir));
  } catch (err) {
    throw new Error(`Failed to save WETH9 artifact: ${err.message}`);
  }

  // Verify on Etherscan (skip for local networks)
  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    console.log("Verifying WETH9 on Etherscan...");
    try {
      await hre.run("verify:verify", { address: await weth9.getAddress(), constructorArguments: [] });
      console.log("WETH9 verified on Etherscan");
    } catch (err) {
      console.error("Etherscan verification failed:", err.message);
    }
  }

  return await weth9.getAddress();
}

main()
  .then(() => {
    console.log("WETH9 deployment completed successfully");
    process.exit(0);
  })
  .catch((err) => {
    console.error("Deployment failed:", err.message);
    process.exit(1);
  });