const { ethers } = require("hardhat");
const fs = require("fs");
const { getLinkedFactory } = require("./utils/linkLibraries");

module.exports = async () => {
  const [deployer] = await ethers.getSigners();
  const hre = require("hardhat");
  console.log("Deploying to network:", hre.network.name);
  console.log("Deploying NonfungiblePositionManager with account:", deployer.address);
  console.log("Deployer balance:", ethers.utils.formatEther(await deployer.getBalance()), "ETH");

  // Check for required artifacts
  if (
    !fs.existsSync("artifacts/factory.json") ||
    !fs.existsSync("artifacts/weth9.json") ||
    !fs.existsSync("artifacts/positionDescriptor.json")
  ) {
    throw new Error("Required artifacts (factory.json, weth9.json, or positionDescriptor.json) not found");
  }
  const { factoryAddress } = JSON.parse(fs.readFileSync("artifacts/factory.json"));
  const { wethAddress } = JSON.parse(fs.readFileSync("artifacts/weth9.json"));
  const { descriptorAddress } = JSON.parse(fs.readFileSync("artifacts/positionDescriptor.json"));

  const PositionManagerFactory = await getLinkedFactory(
    "contracts/uniswap/NonfungiblePositionManager.sol:NonfungiblePositionManager"
  );
  const positionManagerInstance = await PositionManagerFactory.deploy(
    factoryAddress,
    wethAddress,
    descriptorAddress
  );
  await positionManagerInstance.waitForDeployment();

  const address = await positionManagerInstance.getAddress();
  console.log("NonfungiblePositionManager deployed to:", address);

  fs.writeFileSync(
    "artifacts/positionManager.json",
    JSON.stringify({ positionManagerAddress: address }, null, 2)
  );

  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    try {
      console.log("Verifying NonfungiblePositionManager on Etherscan...");
      await hre.run("verify:verify", {
        address,
        constructorArguments: [factoryAddress, wethAddress, descriptorAddress],
      });
    } catch (err) {
      console.error("Etherscan verification failed:", err.message);
    }
  }
};