import React, { useEffect, useState } from "react";
import "./PoolCard.css";
import { useNavigate } from "react-router-dom";
import { loadTokenList } from "../utils/loadTokenList";

const PoolCard = ({ pool, onView }) => {
  const navigate = useNavigate();
  const [tokenData, setTokenData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTokenList = async () => {
      try {
        const list = await loadTokenList(11155111); // Hardcoded Sepolia for now
        setTokenData(list.tokens || []);
      } catch (err) {
        console.error("Failed to load token list:", err);
        setTokenData([]);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTokenList();
  }, []);

  const getTokenMeta = (address) => {
    if (!address) return null;
    return tokenData.find(
      (token) =>
        token.address && token.address.toLowerCase() === address.toLowerCase()
    ) || null;
  };

  if (isLoading) {
    return (
      <div className="pool-card loading">
        <p>Loading pool data...</p>
      </div>
    );
  }

  const tokenA = getTokenMeta(pool.tokenAAddress);
  const tokenB = getTokenMeta(pool.tokenBAddress);

  if (!tokenA || !tokenB) {
    return (
      <div className="pool-card fallback">
        <div className="pool-info">
          <span className="pool-name">🔍 No valid tokens found</span>
          <p>
            It seems like there is no valid token information. You can create a new pool to get
            started.
          </p>
        </div>
        <button className="view-pool-button" onClick={() => navigate('/create-pool')}>
          Go to Create Pool
        </button>
      </div>
    );
  }

  return (
    <div className="pool-card">
      <div className="pool-info">
        <span className="pool-name">
          🔍 Pool {tokenA.symbol} - {tokenB.symbol}
        </span>

        <div className="token-icons">
          {tokenA.logoURI && (
            <img src={tokenA.logoURI} alt={tokenA.symbol} className="token-icon" />
          )}
          {tokenB.logoURI && (
            <img src={tokenB.logoURI} alt={tokenB.symbol} className="token-icon" />
          )}
        </div>

        <p>
          {pool.tokenAAmount} {tokenA.name} ({tokenA.symbol}) +{" "}
          {pool.tokenBAmount} {tokenB.name} ({tokenB.symbol})
        </p>

        <div className="pool-metrics">
          <p><strong>TVL:</strong> Coming soon</p>
          <p><strong>APR:</strong> Coming soon</p>
        </div>
      </div>

      <button className="view-pool-button" onClick={() => navigate('/create-pool')}>
        Go to Create Pool
      </button>
    </div>
  );
};

export default PoolCard;
