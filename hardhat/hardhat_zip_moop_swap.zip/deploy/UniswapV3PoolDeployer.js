// deploy/UniswapV3PoolDeployer.js
const { ethers } = require("hardhat");
const fs = require("fs");
const path = require("path");

async function main() {
  console.log("Starting UniswapV3PoolDeployer deployment script...");

  // Verify Hardhat environment
  const hre = require("hardhat");
  console.log("Hardhat network:", hre.network.name);
  if (hre.network.name !== "localhost" && hre.network.name !== "hardhat") {
    console.log("WARNING: Not running on localhost or hardhat network");
  }

  // Get deployer
  let deployer;
  try {
    [deployer] = await ethers.getSigners();
    console.log("Deployer address:", deployer.address);
    const balance = await ethers.provider.getBalance(deployer.address);
    console.log("Deployer balance:", ethers.formatEther(balance), "ETH");
    if (balance < ethers.parseEther("0.1")) {
      throw new Error("Insufficient deployer balance (< 0.1 ETH)");
    }
  } catch (err) {
    throw new Error(`Failed to get deployer: ${err.message}`);
  }

  // Load factory address
  let factoryAddress;
  try {
    const artifactDir = path.resolve(__dirname, "../saveDeployArtifacts");
    const factoryPath = path.join(artifactDir, "factory.json");
    console.log("Looking for factory.json at:", factoryPath);
    console.log("Directory contents before reading:", fs.readdirSync(artifactDir));
    if (!fs.existsSync(factoryPath)) {
      throw new Error("factory.json not found. Deploy UniswapV3Factory first.");
    }
    const factoryData = JSON.parse(fs.readFileSync(factoryPath));
    factoryAddress = factoryData.factoryAddress;
    if (!factoryAddress) {
      throw new Error("factoryAddress not found in factory.json");
    }
    if ((await ethers.provider.getCode(factoryAddress)) === "0x") {
      throw new Error("Invalid factory address: no code deployed");
    }
    console.log("Using factory address:", factoryAddress);
  } catch (err) {
    throw new Error(`Failed to load factory address: ${err.message}`);
  }

  // Verify contract compilation
  console.log("Attempting to load UniswapV3PoolDeployer contract...");
  let PoolDeployerFactory;
  try {
    PoolDeployerFactory = await ethers.getContractFactory("UniswapV3PoolDeployer");
    console.log("UniswapV3PoolDeployer contract factory loaded successfully");
  } catch (err) {
    throw new Error(`Failed to load UniswapV3PoolDeployer contract: ${err.message}. Check if contracts/uniswap/UniswapV3PoolDeployer.sol exists and is compiled.`);
  }

  // Deploy UniswapV3PoolDeployer
  console.log("Deploying UniswapV3PoolDeployer...");
  let poolDeployer;
  try {
    poolDeployer = await PoolDeployerFactory.deploy({ gasLimit: 5000000 });
    await poolDeployer.waitForDeployment();
    const poolDeployerAddress = await poolDeployer.getAddress();
    console.log("UniswapV3PoolDeployer deployed to:", poolDeployerAddress);
  } catch (err) {
    throw new Error(`UniswapV3PoolDeployer deployment failed: ${err.message}`);
  }

  // Save address to artifacts
  try {
    const artifactDir = path.resolve(__dirname, "../saveDeployArtifacts");
    const artifactPath = path.join(artifactDir, "UniswapV3PoolDeployer.json");
    console.log("Attempting to save artifact to:", artifactPath);
    console.log("Directory contents before writing:", fs.readdirSync(artifactDir));
    const artifactData = { poolDeployerAddress: await poolDeployer.getAddress(), factoryAddress };
    fs.writeFileSync(artifactPath, JSON.stringify(artifactData, null, 2));
    console.log("UniswapV3PoolDeployer address saved to:", artifactPath);
    if (fs.existsSync(artifactPath)) {
      console.log("Verified: UniswapV3PoolDeployer.json exists");
      console.log("Artifact contents:", JSON.stringify(artifactData, null, 2));
    } else {
      throw new Error("Failed to verify UniswapV3PoolDeployer.json existence");
    }
    console.log("Directory contents after writing:", fs.readdirSync(artifactDir));
  } catch (err) {
    throw new Error(`Failed to save PoolDeployer artifact: ${err.message}`);
  }

  // Verify on Etherscan (skip for local networks)
  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    console.log("Verifying UniswapV3PoolDeployer on Etherscan...");
    try {
      await hre.run("verify:verify", { address: await poolDeployer.getAddress(), constructorArguments: [] });
      console.log("UniswapV3PoolDeployer verified on Etherscan");
    } catch (err) {
      console.error("Etherscan verification failed:", err.message);
    }
  }

  return await poolDeployer.getAddress();
}

main()
  .then(() => {
    console.log("UniswapV3PoolDeployer deployment completed successfully");
    process.exit(0);
  })
  .catch((err) => {
    console.error("Deployment failed:", err.message);
    process.exit(1);
  });