require("@nomicfoundation/hardhat-toolbox");
//require("@nomiclabs/hardhat-ethers");
require("@nomicfoundation/hardhat-verify");

module.exports = {
  solidity: {
    compilers: [
      {
        version: "0.7.6",
        settings: {
          evmVersion: "istanbul",
          optimizer: {
            enabled: true,
            runs: 1000,
          },
          metadata: {
            bytecodeHash: "none",
          },
        },
      },
      {
        version: "0.8.0",
        settings: {
          evmVersion: "istanbul",
          optimizer: {
            enabled: true,
            runs: 1000,
          },
          metadata: {
            bytecodeHash: "none",
          },
        },
      },
    ],
    overrides: {
      "contracts/uniswap/NonfungibleTokenPositionDescriptor.sol": {
        version: "0.7.6",
        settings: {
          evmVersion: "istanbul",
          optimizer: {
            enabled: true,
            runs: 1000,
          },
          metadata: {
            bytecodeHash: "none",
          },
        },
      },
      "contracts/uniswap/NFTDescriptor.sol": {
        version: "0.7.6",
        settings: {
          evmVersion: "istanbul",
          optimizer: {
            enabled: true,
            runs: 1000,
          },
          metadata: {
            bytecodeHash: "none",
          },
        },
      },
      "contracts/WETH9.sol": {
        version: "0.8.0",
        settings: {
          evmVersion: "istanbul",
          optimizer: {
            enabled: true,
            runs: 1000,
          },
          metadata: {
            bytecodeHash: "none",
          },
        },
      },
    },
  },
  networks: {
    hardhat: {
      allowUnlimitedContractSize: true,
      chainId: 31337,
    },
    localhost: {
      url: "http://127.0.0.1:8545",
      chainId: 31337,
      gas: 12000000,
      blockGasLimit: 12000000,
    },
    sepolia: {
      url: "https://sepolia.infura.io/v3/ffa5449f44f34b01ab51c931e9687049",
      accounts: [], // MetaMask handles signing
      chainId: 11155111,
    },
  },
  paths: {
    sources: "./contracts",
    artifacts: "./artifacts",
    deployments: "./deploy",
  },
  etherscan: {
    apiKey: "YOUR_ETHERSCAN_API_KEY", // Add if verifying
  },
};