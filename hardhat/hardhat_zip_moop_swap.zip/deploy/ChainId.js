const { ethers } = require("hardhat");
const fs = require("fs");

module.exports = async () => {
  const [deployer] = await ethers.getSigners();
  const hre = require("hardhat");
  console.log("Deploying to network:", hre.network.name);
  console.log("Deploying ChainId with account:", deployer.address);
  console.log("Deployer balance:", ethers.utils.formatEther(await deployer.getBalance()), "ETH");

  const ChainIdFactory = await ethers.getContractFactory("contracts/ChainId.sol:ChainId");
  const chainIdInstance = await ChainIdFactory.deploy();
  await chainIdInstance.waitForDeployment();

  const address = await chainIdInstance.getAddress();
  console.log("ChainId deployed to:", address);

  fs.writeFileSync("artifacts/chainId.json", JSON.stringify({ chainIdAddress: address }, null, 2));

  if (hre.network.name !== "hardhat" && hre.network.name !== "localhost") {
    try {
      console.log("Verifying ChainId on Etherscan...");
      await hre.run("verify:verify", { address, constructorArguments: [] });
    } catch (err) {
      console.error("Etherscan verification failed:", err.message);
    }
  }
};